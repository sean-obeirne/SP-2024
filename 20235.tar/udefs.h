/**
** @file udefs.h
**
** @author Numerous CSCI-452 classes
**
** User-level definitions for the baseline system.
*/

#ifndef UDEFS_H_
#define UDEFS_H_

#ifndef SP_ASM_SRC

// User code needs the user library headers

#include "ulib.h"

#endif
/* SP_ASM_SRC */

#endif
